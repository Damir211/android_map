# TSN_DEMO_05_Map
Работа с картами google
![Screenshot](Screenshot_1522254011.png)

![Screenshot](Screenshot_1522255144.png)
